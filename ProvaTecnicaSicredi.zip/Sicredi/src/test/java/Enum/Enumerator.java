package Enum;

public class Enumerator {
	public static final String sigilo="S";
	public static final String bloqueado="S";
	public  final String validaTag="SN";
	public static final String validaEncerramentoSuspencao="Este prazo de Suspensão Tema/Controvérsia será encerrado. As informações do processo serão enviadas ao CNJ automaticamente."; 
}
