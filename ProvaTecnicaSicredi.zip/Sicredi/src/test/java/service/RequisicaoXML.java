package service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import dto.SimuladorDTO;
import stepDefinition.DTOStepDefinition;

public class RequisicaoXML {
	DTOStepDefinition dto = new DTOStepDefinition();
	SimuladorDTO simuladorDTO = new SimuladorDTO();;
	public RequisicaoXML() {

	}

		public void RequestAPISicredi(){
	
		BufferedReader httpResponseReader = null;
		try {
			// Connect to the web server endpoint
			URL serverUrl = new URL("http://5b847b30db24a100142dce1b.mockapi.io/api/v1/simulador");
			HttpURLConnection urlConnection = (HttpURLConnection) serverUrl.openConnection();
			urlConnection.setDoOutput(true);
			// Set HTTP method as GET
			urlConnection.setRequestMethod("GET");
			urlConnection.setDoOutput(true);

			int code =urlConnection.getResponseCode();
			httpResponseReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
			String lineRead;
			lineRead = httpResponseReader.readLine();
			
				System.out.println("Response =" + lineRead);
			
			 String json_str =lineRead;
			 JSONObject my_obj = new JSONObject(json_str);
			 
			//recupera campo por campo com o método get() e imprime cada um
			    int id = my_obj.getInt("id");
			    JSONArray meses = my_obj.getJSONArray("meses");
			    JSONArray valor = my_obj.getJSONArray("valor");
			    System.out.println("id: " + id);
			    System.out.println("meses: " + meses);
			    System.out.println("valor: " + valor);
			    try {
					System.out.println(valor.get(2));
					System.out.println(meses.get(2));
			    	dto.altero_propriedade_dto("aplicacao",valor.get(2));
					dto.altero_propriedade_dto("poupanca","300,00");
					dto.altero_propriedade_dto("tempo",meses.get(2));				
					
				} catch (Throwable e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {

			if (httpResponseReader != null) {
				try {
					httpResponseReader.close();
				} catch (IOException ioe) {
					// Close quietly
				}
			}
		}

	}

	
		

}
