package automation.utils;

public interface IVerifyMethod {
	 public String getMethod();
}
