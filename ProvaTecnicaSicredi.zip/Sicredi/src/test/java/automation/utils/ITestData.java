package automation.utils;

import java.util.List;

import automation.utils.VerifyDTO;

public interface ITestData {
	public List<VerifyDTO> getValidations();
}
