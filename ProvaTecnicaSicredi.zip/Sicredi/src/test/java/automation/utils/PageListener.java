package automation.utils;

public interface PageListener {

		 void windowClosed();
	


}
