package stepDefinition;

import automation.Sicredi;
import automation.utils.ArquivoUtils;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import dto.SimuladorDTO;
import paginas.PaginaSimulador;
import service.RequisicaoXML;
import automation.Pages;
import session.ThreadManager;

public class SimuladorStepDefinition extends Sicredi{
	RequisicaoXML req = new RequisicaoXML();
	private Pages getPages() {
		return ThreadManager.getSession().getPages();
	}
	
	
	@When("^preenche campos do formulario$")
	public void preenche_campos_do_formulario() throws Throwable {
		SimuladorDTO simulador  = (SimuladorDTO)ThreadManager.getSession().getCurrentDTO();
		String aplicacao=simulador.getAplicacao();
		String poupanca=simulador.getPoupanca();
		String tempo=simulador.getTempo();
		getPages().get(PaginaSimulador.class).preencherCampos(aplicacao, poupanca, tempo);
		
		
	}
	@When("^preenche campos do formulario \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void preenche_campos_do_formulario(String aplicacao, String poupanca, String tempo) throws Throwable {
		getPages().get(PaginaSimulador.class).preencherCampos(aplicacao, poupanca, tempo);
		ArquivoUtils.tiraScreenshot("Sicredi2.jpg");
		
	}

	@And("^clico no botao simular$")
	public void clico_no_bot_o_simular() throws Throwable {
		getPages().get(PaginaSimulador.class).clicarBotaoSimular();
		ArquivoUtils.tiraScreenshot("Sicredi3.jpg");
	    
	}
	@And("^clico no botao perfil$")
	public void clico_no_bot_o_perfil() throws Throwable {
		getPages().get(PaginaSimulador.class).clicarBotaoPerfil();
		ArquivoUtils.tiraScreenshot("Sicredi7.jpg");
	    
	}
	@And("^clico no botao limpar$")
	public void clico_no_bot_o_limpar() throws Throwable {
		getPages().get(PaginaSimulador.class).clicoBotaoLimpar();
		ArquivoUtils.tiraScreenshot("Sicredi4.jpg");
	    
	}
	@And("^seleciono periodo$")
	public void seleciono_periodo() throws Throwable {
		SimuladorDTO simulador  = (SimuladorDTO)ThreadManager.getSession().getCurrentDTO();
		String tipo=simulador.getPeriodo();
		getPages().get(PaginaSimulador.class).clicoSelecionoPeriodo(tipo);
		ArquivoUtils.tiraScreenshot("Sicredi4.jpg");
	    
	}
	@And("^usa api sicredi$")
	public void usa_api_sicredi() throws Throwable {
		req.RequestAPISicredi();
	    
	}
	
	@Then("^valido mensagem de erro na tela$")
	public void valido_mensagem_de_erro_na_tela() throws Throwable {
		getPages().get(PaginaSimulador.class).validaErroTela();
	}
	@Then("^valido simulacao realizada$")
	public void valido_simulacao_realizadada() throws Throwable {
		getPages().get(PaginaSimulador.class).validoSimulacaoRealizada();
		ArquivoUtils.tiraScreenshot("Sicredi5.jpg");
	}
	@Then("^clico botao refazer$")
	public void clico_botao_refazer() throws Throwable {
		getPages().get(PaginaSimulador.class).validoSimulacaoRealizada();
		ArquivoUtils.tiraScreenshot("Sicredi6.jpg");
	}

}
