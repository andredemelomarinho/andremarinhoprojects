package stepDefinition;


import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import org.apache.log4j.Logger;
import automation.Sicredi;
import automation.Pages;
import automation.utils.TestData;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import dto.SimuladorDTO;
import dto.baseDTO.SimuladorDTOBase;
import session.ThreadManager;

public class DTOStepDefinition extends Sicredi {
	
	SimuladorDTO simuladorDTO = null;
	
	
	private Pages getPages() {
		return ThreadManager.getSession().getPages();
	}
		
	@Given("^uso dados simulacao realizado$")
	public void uso_dados_simulacao_realizado() throws Throwable {
		simuladorDTO = SimuladorDTOBase.getSimuladorBaseRealizado();
		ThreadManager.getSession().setCurrentDTO(simuladorDTO);
	   
	}
	@Given("^altero propriedade dto \"([^\"]*)\" \"([^\"]*)\"$")
	public void altero_propriedade_dto(String nomePropriedade, Object valor) throws Throwable {
		Object prop;
		try {
			TestData dto = ThreadManager.getSession().getCurrentDTO();
			PropertyDescriptor descriptor = new PropertyDescriptor(
					dto.getClass().getDeclaredField(nomePropriedade).getName(),
					dto.getClass());
			prop = descriptor.getReadMethod().invoke(dto);
			Object val = null;
			if(prop != null) {
				val = returnValueByType(prop.getClass(), valor);
			}
			setField(dto, nomePropriedade, val);
		} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchFieldException
				| SecurityException | IntrospectionException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace(); 
		}

	}
	private Object returnValueByType(Class<?> propertyType, Object valor) {

		Object val = null;
		switch (propertyType.getTypeName()) {
		case "java.lang.String":
			val = String.valueOf(valor);
			break;
		case "java.lang.Boolean":
			val = Boolean.parseBoolean(valor.toString());
			break;
		case "java.lang.Long":
			val = Long.parseLong(valor.toString());
			break;
		case "java.lang.Integer":
			val = Integer.parseInt(valor.toString());
			break;

		}

		return val;
	}

	public static boolean setField(Object targetObject, String fieldName, Object fieldValue) {
		Field field;
		try {
			field = targetObject.getClass().getDeclaredField(fieldName);
		} catch (NoSuchFieldException e) {
			field = null;
		}
		Class superClass = targetObject.getClass().getSuperclass();
		while (field == null && superClass != null) {
			try {
				field = superClass.getDeclaredField(fieldName);
			} catch (NoSuchFieldException e) {
				superClass = superClass.getSuperclass();
			}
		}
		if (field == null) {
			return false;
		}
		field.setAccessible(true);
		try {
			field.set(targetObject, fieldValue);
			return true;
		} catch (IllegalAccessException e) {
			return false;
		}
	}

	
	
}
